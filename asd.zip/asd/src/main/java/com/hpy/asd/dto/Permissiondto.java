package com.hpy.asd.dto;

import com.hpy.asd.entities.Permission;

import java.util.List;

public interface Permissiondto {
    public List<com.hpy.asd.entities.Permission> findAll();
    public Permission findByFeature(int feature);
}
