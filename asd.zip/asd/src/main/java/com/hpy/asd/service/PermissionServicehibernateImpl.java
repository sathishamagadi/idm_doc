package com.hpy.asd.service;


import com.hpy.asd.dto.PermissiondtohibernateImpl;
import com.hpy.asd.entities.Permission;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class PermissionServicehibernateImpl implements PermissionService {

    private PermissiondtohibernateImpl permissiondto;

    @Autowired
    public PermissionServicehibernateImpl(PermissiondtohibernateImpl thePermissiondto)
    {
        permissiondto = thePermissiondto;
    }

    @Override
    @Transactional
    public List<Permission> findAll() {
        return permissiondto.findAll();
    }

    @Override
    @Transactional
    public Permission findByFeature(int feature) {
        return null;
    }


}
