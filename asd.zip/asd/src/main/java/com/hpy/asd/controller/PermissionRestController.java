package com.hpy.asd.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hpy.asd.entities.Permission;
import com.hpy.asd.service.PermissionService;

import java.util.List;

@RestController
@RequestMapping("/api")
public class PermissionRestController
{
    private PermissionService permissionService;

    @Autowired
    public PermissionRestController(PermissionService  thePermissionService)
    {
        permissionService = thePermissionService;
    }
    @GetMapping("/permissions")
    public List<Permission> findAll()
    {
        return permissionService.findAll();
    }

}
