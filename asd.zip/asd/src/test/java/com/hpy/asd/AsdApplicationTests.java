package com.hpy.asd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsdApplicationTests {

	@Test
	void contextLoads() {
	}

}
